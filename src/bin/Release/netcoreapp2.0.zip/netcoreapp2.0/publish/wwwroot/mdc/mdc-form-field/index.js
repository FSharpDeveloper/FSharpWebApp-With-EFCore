/**
 * @license
 * Copyright 2017 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import MDCComponent from '@material/base/component';
import MDCFormFieldFoundation from './foundation';
/* eslint-disable no-unused-vars */
import {MDCSelectionControl} from '@material/selection-control';
/* eslint-enable no-unused-vars */

/**
 * @extends MDCComponent<!MDCFormFieldFoundation>
 */
class MDCFormField extends MDCComponent {
  static attachTo(root) {
    return new MDCFormField(root);
  }

  /** @param {?MDCSelectionControl} input */
  set input(input) {
    this.input_ = input;
  }

  /** @return {?MDCSelectionControl} */
  get input() {
    return this.input_;
  }

  constructor(...args) {
    super(...args);

    /** @private {?MDCSelectionControl} */
    this.input_;
  }

  /**
   * @return {!Element}
   * @private
   */
  get label_() {
    const {LABEL_SELECTOR} = MDCFormFieldFoundation.strings;
    return /** @type {!Element} */ (this.root_.querySelector(LABEL_SELECTOR));
  }

  /** @return {!MDCFormFieldFoundation} */
  getDefaultFoundation() {
    return new MDCFormFieldFoundation({
      registerInteractionHandler: (type, handler) => this.label_.addEventListener(type, handler),
      deregisterInteractionHandler: (type, handler) => this.label_.removeEventListener(type, handler),
      activateInputRipple: () => {
        if (this.input_ && this.input_.ripple) {
          this.input_.ripple.activate();
        }
      },
      deactivateInputRipple: () => {
        if (this.input_ && this.input_.ripple) {
          this.input_.ripple.deactivate();
        }
      },
    });
  }
}

export {MDCFormField, MDCFormFieldFoundation};
